# MigraineEmaxSim 0.5.1

This download contains:

- `MigraineEmaxSim/`: the readable package source and four analysis scripts.
- `MigraineEmaxSim_0.5.1.tar.gz`: source archive for installation in R.
- `fix_plot_em_cm.R`: immediate plotting patch for an existing 0.5.0 session.

To recover from the reported plotting error without repeating calibration,
source `fix_plot_em_cm.R` from this download and rerun the failed plotting
call. Your current calibration object and saved RDS are compatible. The
package itself contains the same fix for subsequent sessions.

Begin with `MigraineEmaxSim/README.md`. Install the dependencies and the
package, restart R, then run the scripts from the `MigraineEmaxSim` directory:

```r
source("analysis/01_calibrate_prior.R")
source("analysis/02_historical_meta.R")
source("analysis/03_hope_update.R")
source("analysis/04_programs.R")
```

`analysis/walk_through_one_program.R` is an optional line-by-line example.
`analysis/optional_diagnostics.R` is separate from the main workflow.

The source uses tidyverse components, Stan for both fitting steps, and
DoseFinding for MCP testing. Comments and intermediate quantities explain
the scientific calculations. Results are written to `results_R_readable/`.

The known HOPE placebo baseline-SD input is corrected to 4.6, retaining the
supplied 4.3 for traceability. R/Stan execution and package runtime checks
could not be performed in the authoring environment. No new fitted results
are included; see `MigraineEmaxSim/VALIDATION.md` for the exact status.
