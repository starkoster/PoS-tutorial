# Validation status of version 0.5.1

The reported plot_em_cm() error in 0.5.0 was traced to tibble's sequential
column evaluation: the new quantity column replaced the scalar loop variable
used by the subsequent CM column lookup. The patch extracts EM/CM vectors
first and uses distinct callback argument names. A focused R regression script
now covers row counts 1, 2, 3001 and 6002, single/multiple stages, matched
EM/CM values, and construction of related plots. This script is provided but
has not been executed here because R is unavailable.

Completed in the authoring environment:

- Compared the patch with the distributed 0.5.0 archive: all 16 non-plotting
  R, Stan and input-CSV files are byte-for-byte unchanged.
- Reviewed DoseFinding's official Mods and MCTtest documentation and source
  for decreasing effects, the general-summary interface, precomputed critical
  values and the returned test statistics.
- Checked that all 35 exported functions are defined and have help entries.
- Checked matching delimiters and closed strings in the R and Stan sources.
  This is a structural scan, not an R parser or compiler check.
- Checked that the driver calls exactly the four core stages and excludes the
  optional diagnostic script and removed diagnostic gate.
- Checked the source interfaces for conditional selected-dose Phase 3 and
  reuse of fixed Phase 3 outcomes in the screened Program 1 comparison.
- Independently checked the clinical transformation, effect ordering, baseline
  bounds and inverse mapping numerically in Python on 10,000 latent draws.
- Checked that the raw supplied arm CSV is unchanged and that historical
  preprocessing retains ten change rows and six baseline rows.

Not completed here because R and CmdStan are unavailable:

- Executing the new R functions or the focused regression checks in tests/core.R.
- Compiling and sampling the Stan models.
- R CMD build or R CMD check.
- Fitting new posteriors or producing new trial-program PoS results.

The included tar.gz is a source-installation archive assembled from the
package files; it is not represented as an R CMD build product. The ZIP also
includes the convenient top-level analysis directory. Those scripts are
duplicated under inst/analysis for installation.

After installing, run tests/core.R, then the four analysis stages. Native
Stan warnings and the optional manual diagnostic review remain available.
