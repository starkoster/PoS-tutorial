# Immediate fix for plot_em_cm() in MigraineEmaxSim 0.5.0.
# Source this file in the existing R session, then rerun the failed plot call.
# The existing calibration object and saved RDS remain usable.
# This overrides only plot_em_cm() in the current session.
# R runtime validation was unavailable in the authoring environment.

plot_em_cm <- function(draw_sets) {

  # Use matched EM/CM draws. Thinning is for plotting speed, not for inference.
  data <- purrr::imap_dfr(draw_sets, function(stage_draws, stage_name) {

    keep <- unique(round(seq(
      1, nrow(stage_draws), length.out = min(3000, nrow(stage_draws))
    )))

    purrr::map_dfr(c("baseline", "placebo", "active"), function(quantity_name) {

      # Extract both vectors before building the tibble. Its sequential column
      # evaluation must not replace the scalar name used to select a draw column.
      em_values <- stage_draws[[paste0(quantity_name, "_em")]][keep]
      cm_values <- stage_draws[[paste0(quantity_name, "_cm")]][keep]

      tibble::tibble(
        stage = stage_name,
        quantity = quantity_name,
        EM = em_values,
        CM = cm_values
      )
    })
  }) |>
    dplyr::mutate(stage = factor(stage, levels = names(draw_sets)))

  ggplot2::ggplot(data, ggplot2::aes(EM, CM)) +
    ggplot2::geom_point(alpha = 0.08, size = 0.6, colour = "#001965") +
    ggplot2::geom_abline(slope = 1, intercept = 0, linetype = 2, colour = "#8E99AB") +
    ggplot2::facet_wrap(~ stage + quantity, scales = "free", ncol = 3) +
    ggplot2::labs(x = "EM (MMDs)", y = "CM (MMDs)", title = "EM/CM clinical relationships") +
    MigraineEmaxSim::analysis_theme()
}
